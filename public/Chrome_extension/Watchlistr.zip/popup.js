const GENRES = {
  28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy", 80: "Crime",
  99: "Documentary", 18: "Drama", 10751: "Family", 14: "Fantasy", 36: "History",
  27: "Horror", 10402: "Music", 9648: "Mystery", 10749: "Romance", 878: "Sci-Fi",
  10770: "TV Movie", 53: "Thriller", 10752: "War", 37: "Western"
};

let activeList = [];
let watchedList = [];
let currentView = 'active'; // 'active' or 'watched'
let debounceTimer;

document.addEventListener('DOMContentLoaded', initialize);

function initialize() {
  const searchInput = document.getElementById('search-input');
  
  // View Toggles
  document.getElementById('view-active').addEventListener('click', () => switchView('active'));
  document.getElementById('view-watched').addEventListener('click', () => switchView('watched'));
  
  // Existing Controls
  document.getElementById('filter-genre').addEventListener('change', renderLocalView);
  document.getElementById('sort-order').addEventListener('change', renderLocalView);
  document.getElementById('back-btn').addEventListener('click', switchToLocal);

  // Search Logic
  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim().toLowerCase();
    clearTimeout(debounceTimer);

    if (query.length === 0) {
      if (document.getElementById('back-btn').style.display !== 'none') switchToLocal();
      else renderLocalView();
      return;
    }

    const localMatches = getLocalMatches(query);

    if (localMatches.length > 0) {
      renderLocalView(); // Show local matches instantly
    } else {
      // Only auto-search online if we are in 'active' view
      if (currentView === 'active') {
         renderLocalView(); // Shows empty state briefly
         debounceTimer = setTimeout(() => triggerOnlineSearch(query), 600);
      } else {
         renderLocalView(); // Just show empty in watched view
      }
    }
  });

  loadLists();
}

function loadLists() {
  chrome.storage.local.get({ watchlist: [], watchedlist: [] }, (result) => {
    activeList = result.watchlist;
    watchedList = result.watchedlist;
    populateGenreFilter();
    updateHeaderCount();
    renderLocalView();
  });
}

function switchView(view) {
  currentView = view;
  
  // Toggle UI styling
  document.getElementById('view-active').classList.toggle('active', view === 'active');
  document.getElementById('view-watched').classList.toggle('active', view === 'watched');
  
  // Reset Search
  document.getElementById('search-input').value = '';
  document.getElementById('back-btn').style.display = 'none';
  document.getElementById('app-title').innerText = "WATCHLISTR";
  document.getElementById('filters-row').style.display = 'flex';
  
  updateHeaderCount();
  renderLocalView();
}

function updateHeaderCount() {
  const count = currentView === 'active' ? activeList.length : watchedList.length;
  const label = currentView === 'active' ? 'Movies' : 'Seen';
  document.getElementById('list-count').innerText = `${count} ${label}`;
}

function getLocalMatches(query) {
  const sourceList = currentView === 'active' ? activeList : watchedList;
  const genreFilter = document.getElementById('filter-genre').value;
  
  return sourceList.filter(movie => {
    const matchesGenre = (genreFilter === 'all') || (movie.genres && movie.genres.includes(genreFilter));
    const matchesSearch = movie.title.toLowerCase().includes(query);
    return matchesGenre && matchesSearch;
  });
}

function switchToLocal() {
  document.getElementById('back-btn').style.display = 'none';
  document.getElementById('app-title').innerText = "WATCHLISTR";
  document.getElementById('filters-row').style.display = 'flex';
  renderLocalView();
}

function renderLocalView() {
  const container = document.getElementById('movie-list');
  const emptyState = document.getElementById('empty-state');
  const searchQuery = document.getElementById('search-input').value.toLowerCase().trim();
  const sortOrder = document.getElementById('sort-order').value;

  let filtered = getLocalMatches(searchQuery);

  // Sorting Logic
  filtered.sort((a, b) => {
    const timeA = a.timestamp || 0;
    const timeB = b.timestamp || 0;
    const yearA = parseInt(a.year) || 0;
    const yearB = parseInt(b.year) || 0;

    switch (sortOrder) {
      case 'added_desc': return timeB - timeA;
      case 'added_asc':  return timeA - timeB;
      case 'year_desc':  return yearB - yearA;
      case 'year_asc':   return yearA - yearB;
      default: return 0;
    }
  });

  container.innerHTML = '';

  if (filtered.length === 0) {
    if (searchQuery.length > 0 && currentView === 'active') {
        container.innerHTML = '<p style="text-align:center; color:#444; font-size:12px; margin-top:20px;">...</p>';
    } else {
        emptyState.querySelector('p').innerText = currentView === 'active' ? "Your list is empty." : "No history yet.";
        emptyState.style.display = 'block';
    }
  } else {
    emptyState.style.display = 'none';
    filtered.forEach(movie => createCard(movie, container, currentView === 'active' ? 'manage' : 'history'));
  }
}

function triggerOnlineSearch(query) {
  document.getElementById('back-btn').style.display = 'block';
  document.getElementById('app-title').innerText = "ADD MOVIE";
  document.getElementById('filters-row').style.display = 'none';
  document.getElementById('empty-state').style.display = 'none';
  
  const container = document.getElementById('movie-list');
  container.innerHTML = `
    <div class="loader-container">
        <div class="spinner"></div>
        <span>Searching TMDB...</span>
    </div>`;

  chrome.runtime.sendMessage({ action: "search_tmdb", query: query }, (response) => {
    if (response && response.success) {
      renderOnlineResults(response.data.results);
    } else {
      container.innerHTML = '<p style="text-align:center; color:#e50914; padding:20px;">Error connecting to TMDB.</p>';
    }
  });
}

function renderOnlineResults(movies) {
  const container = document.getElementById('movie-list');
  container.innerHTML = '';
  
  if (!movies || movies.length === 0) {
    container.innerHTML = '<p style="text-align:center; color:#888; padding:20px;">No results found.</p>';
    return;
  }

  // Check both lists to prevent dupes
  const allIds = new Set([...activeList, ...watchedList].map(m => m.id));

  movies.slice(0, 10).forEach(movie => {
    const genreNames = movie.genre_ids ? movie.genre_ids.map(id => GENRES[id]).filter(Boolean).slice(0, 2).join(", ") : "Unknown";
    const movieObj = {
      id: movie.id,
      title: movie.title,
      year: movie.release_date ? movie.release_date.split('-')[0] : 'N/A',
      poster: movie.poster_path,
      genres: genreNames,
      overview: movie.overview
    };
    createCard(movieObj, container, 'add', allIds.has(movie.id));
  });
}

function createCard(movie, container, mode, isDuplicate = false) {
  const card = document.createElement('div');
  card.className = 'movie-card';

  // Open IMDb on click
  card.onclick = () => {
    const query = encodeURIComponent(`${movie.title} ${movie.year}`);
    // Using IMDb "find" by title is the safest bet without knowing the IMDb ID
    window.open(`https://www.imdb.com/find?q=${query}&s=tt`, '_blank');
  };

  const posterHtml = getPosterHtml(movie.poster, 'poster-img');
  const genreDisplay = movie.genres ? movie.genres : "Gen N/A";
  let overviewText = movie.overview || "No description available.";

  // Dynamic Buttons
  let actionHtml = '';
  
  if (mode === 'add') {
     actionHtml = `<button class="action-btn add-btn" ${isDuplicate ? 'disabled' : ''}>${isDuplicate ? 'IN LIST' : 'ADD'}</button>`;
  } else if (mode === 'manage') {
     // Active List: Watch (Eye) + Delete (Trash)
     actionHtml = `
       <div class="card-actions">
         <button class="action-btn watch-btn" title="Mark as Watched">
           <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
         </button>
         <button class="action-btn delete-btn" title="Remove">&times;</button>
       </div>`;
  } else {
     // History List: Only Delete (Trash)
     actionHtml = `
       <div class="card-actions">
         <button class="action-btn delete-btn" style="height:100%" title="Remove">&times;</button>
       </div>`;
  }

  card.innerHTML = `
    ${posterHtml}
    <div class="card-details">
      <div class="card-title" title="${movie.title}">${movie.title}</div>
      <div class="card-meta">
         <span class="year-badge">${movie.year}</span>
         <span class="meta-divider">&bull;</span>
         <span class="card-genre">${genreDisplay}</span>
      </div>
      <div class="card-overview">${overviewText}</div>
    </div>
    ${actionHtml}
  `;

  // Attach Listeners
  if (mode === 'add') {
    const btn = card.querySelector('.add-btn');
    btn.onclick = (e) => { e.stopPropagation(); if (!isDuplicate) addMovieFromSearch(movie, btn); };
  } else {
    // Delete Button
    const delBtn = card.querySelector('.delete-btn');
    if (delBtn) delBtn.onclick = (e) => { e.stopPropagation(); removeMovie(movie.id); };

    // Watch Button
    const watchBtn = card.querySelector('.watch-btn');
    if (watchBtn) watchBtn.onclick = (e) => { e.stopPropagation(); markAsWatched(movie); };
  }

  container.appendChild(card);
}

function markAsWatched(movie) {
  // 1. Remove from Active
  activeList = activeList.filter(m => m.id !== movie.id);
  
  // 2. Add to Watched (Update timestamp to now)
  const watchedMovie = { ...movie, timestamp: Date.now(), watched: true };
  watchedList.push(watchedMovie);

  // 3. Save Both
  chrome.storage.local.set({ watchlist: activeList, watchedlist: watchedList }, () => {
    updateHeaderCount();
    renderLocalView(); // Will disappear from current view
  });
}

function removeMovie(id) {
  if (currentView === 'active') {
    activeList = activeList.filter(m => m.id !== id);
    chrome.storage.local.set({ watchlist: activeList }, () => {
      updateHeaderCount();
      renderLocalView();
    });
  } else {
    watchedList = watchedList.filter(m => m.id !== id);
    chrome.storage.local.set({ watchedlist: watchedList }, () => {
      updateHeaderCount();
      renderLocalView();
    });
  }
}

function addMovieFromSearch(movie, btnElement) {
  movie.timestamp = Date.now();
  activeList.push(movie);
  
  chrome.storage.local.set({ watchlist: activeList }, () => {
    btnElement.innerText = "ADDED";
    btnElement.style.backgroundColor = "#2ecc71";
    btnElement.style.color = "#000";
    btnElement.disabled = true;
    setTimeout(() => {
      document.getElementById('search-input').value = '';
      clearTimeout(debounceTimer);
      switchToLocal();
    }, 800);
  });
}

function getPosterHtml(path, className) {
  const svgIcon = `<svg viewBox="0 0 24 24"><path d="M19.8 4H4.2C3 4 2 5 2 6.2v11.6C2 19 3 20 4.2 20h15.6c1.2 0 2.2-1 2.2-2.2V6.2C22 5 21 4 19.8 4zM20 18H4V6h16v12z"/></svg>`;
  if (path) {
    return `<img src="https://image.tmdb.org/t/p/w154${path}" class="${className}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div class="${className === 'poster-img' ? 'poster-placeholder' : 'watchlistr-poster-placeholder'}" style="display:none">${svgIcon}</div>`;
  } else {
    return `<div class="${className === 'poster-img' ? 'poster-placeholder' : 'watchlistr-poster-placeholder'}">${svgIcon}</div>`;
  }
}

function populateGenreFilter() {
  const genreSelect = document.getElementById('filter-genre');
  const uniqueGenres = new Set();
  [...activeList, ...watchedList].forEach(movie => {
    if (movie.genres) movie.genres.split(', ').forEach(g => uniqueGenres.add(g));
  });
  const sortedGenres = Array.from(uniqueGenres).sort();
  genreSelect.innerHTML = '<option value="all">All Genres</option>';
  sortedGenres.forEach(genre => {
    const opt = document.createElement('option');
    opt.value = genre;
    opt.innerText = genre;
    genreSelect.appendChild(opt);
  });
}