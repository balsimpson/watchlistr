const TMDB_API_KEY = 'bcde1195dc8ce8278f7fd88e160d3d72';

// 1. Context Menu (Existing)
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "add-to-watchlistr",
    title: "Add '%s' to Watchlistr",
    contexts: ["selection"]
  }, () => {
    if (chrome.runtime.lastError) console.log("Menu item exists.");
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "add-to-watchlistr") {
    fetchMovieData(info.selectionText).then(data => {
      chrome.tabs.sendMessage(tab.id, {
        action: "show_movie_options",
        movies: data.results ? data.results.slice(0, 3) : [] 
      });
    }).catch(err => console.error(err));
  }
});

// 2. Message Handler (New - for Popup Search)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "search_tmdb") {
    fetchMovieData(request.query).then(data => {
      sendResponse({ success: true, data: data });
    }).catch(error => {
      sendResponse({ success: false, error: error.message });
    });
    return true; // Keep channel open for async response
  }
});

// Helper Function
async function fetchMovieData(query) {
  if (TMDB_API_KEY === 'YOUR_TMDB_API_KEY') {
    throw new Error("Missing API Key");
  }
  const response = await fetch(
    `https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}`
  );
  if (!response.ok) throw new Error("API Error");
  return await response.json();
}